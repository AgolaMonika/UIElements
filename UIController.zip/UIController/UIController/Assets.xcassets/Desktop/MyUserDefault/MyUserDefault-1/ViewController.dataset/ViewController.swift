//
//  ViewController.swift
//  MyUserDefault
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let myLabel : UILabel = {
        let label = UILabel()
        label.text = ""
        label.textAlignment = .center
        label.backgroundColor = .gray
        return label
    }()
    private let myButton : UIButton = {
        let button = UIButton()
       button.setTitle("", for: .normal)
        button.addTarget(self, action: #selector(logoutTapped), for: .touchUpInside)
        button.backgroundColor = .gray
        button.layer.cornerRadius = 6
        return button
    }()
    
    override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            checkAuth()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(myLabel)
        view.addSubview(myButton)
        view.backgroundColor = .white
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        myLabel.frame = CGRect(x: 40, y: 200, width: view.width-80, height: 40)
        myButton.frame = CGRect(x: 40, y: myLabel.bottom + 20, width:view.width-80,height: 40)
        
    }
    private func checkAuth(){
        if let uname = UserDefaults.standard.string(forKey: "username"){
            myLabel.text = "welcome \(uname)"
        }
        else{
            let vc = LoginVC()
            let nev = UINavigationController(rootViewController: vc)
        nev.modalPresentationStyle = .fullScreen
            nev.setNavigationBarHidden(true, animated: false)
            present(nev,animated: false)
        }
    }
    
    
    @objc private func logoutTapped(){
        UserDefaults.standard.setValue(nil, forKey: "username")
        checkAuth()
    }
    


}

