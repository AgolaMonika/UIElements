//
//  NewNoteVC.swift
//  MyFileManager
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class NewNoteVC: UIViewController {
    
    private var nameTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = ""
        textField.textAlignment = .center
        textField.borderStyle = .roundedRect
        textField.backgroundColor = .gray
        return textField
    }()
    private let myTextView: UITextView = {
       let textview = UITextView()
        textview.text = "this is a text view"
        textview.textAlignment = .center
        textview.backgroundColor = .gray
        return textview
    }()
    
    private let saveButton: UIButton = {
        let button = UIButton();
        button.setTitle("", for: .normal)
        button.addTarget(self, action: #selector(saveNote), for: .touchUpInside)
        button.tintColor = .white
        button.backgroundColor = .gray
        button.layer.cornerRadius = 6
        return button
    }()
    private let deleteButton: UIButton = {
        let button = UIButton();
        button.setTitle("Delete", for: .normal)
        button.addTarget(self, action: #selector(deleteNote), for: .touchUpInside)
        button.tintColor = .white
        button.backgroundColor = .gray
        button.layer.cornerRadius = 6
        return button
    }()
    
    @objc private func saveNote(){
        let name = nameTextField.text
        let content = myTextView.text
        
        let filePath = FileManagerService.getDocDir().appendingPathComponent("\(name).txt")
        do{
            try content?.write(to: filePath, atomically: true, encoding: .utf8)
        }catch{
            print("error")
        }
    }
    
    @objc private func deleteNote(){
    
        
        let filePath = FileManagerService.getDocDir().appendingPathComponent("Xyz.txt")
        do{
            try FileManager.default.removeItem(at: filePath)
            print("delete")
        }catch{
            print("error")
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        do{
            let filePath = FileManagerService.getDocDir().appendingPathComponent("Xyz.txt")
            let fetchedContent = try String(contentsOf: filePath)
            print(fetchedContent)
        }catch{
            print(error)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(nameTextField)
        view.addSubview(myTextView)
        view.addSubview(saveButton)
        view.addSubview(deleteButton)

        
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        nameTextField.frame = CGRect(x: 40, y: 100, width: view.width - 80, height: 40)
        myTextView.frame = CGRect(x: 40, y: nameTextField.bottom + 20, width: view.width - 80, height: 40)
        saveButton.frame = CGRect(x: 40, y: myTextView.bottom + 20, width: view.width - 80, height: 40)
        deleteButton.frame = CGRect(x: 40, y: saveButton.bottom + 20, width: view.width - 80, height: 40)    }

}
