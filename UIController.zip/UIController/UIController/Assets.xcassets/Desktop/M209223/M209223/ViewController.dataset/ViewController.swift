//
//  ViewController.swift
//  M209223
//
//  Created by DCS on 07/09/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
	class Btn: UIButton {
		let myBtn = Btn();
		mybtn.Target(action: #selector(redirect))
		
	}
	func redirect() -> Int {
		let vc =
	}
	
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

