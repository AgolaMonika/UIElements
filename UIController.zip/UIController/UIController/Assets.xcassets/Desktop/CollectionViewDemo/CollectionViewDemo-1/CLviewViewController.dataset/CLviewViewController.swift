//
//  CLviewViewController.swift
//  CollectionViewDemo
//
//  Created by DCS on 26/11/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class CLviewViewController: UIViewController{
    private let myCollectionView = UICollectionView()
    private let cityArray=["Berlin","Rio","Tokyo","Moscow"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Collection View"
        view.addSubview(myCollectionView)

        
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        myCollectionView.frame=CGRect(x: 0, y: view.safeAreaInsets.top, width: view.width, height: view.height-view.safeAreaInsets.bottom)
    }

}
extension CLviewViewController : UICollectionViewDataSource, UICollectionViewDelegate{
    
    private func setupCollectionView(){
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        myCollectionView.register(UIViewController.self, forCellWithReuseIdentifier: "City Cell")
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cityArray.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "City Cell", for: indexPath)
        //cell.myLabel.text = self.cityArray[indexPath.row]
        cell.backgroundColor = .red
        return cell
    }
    
    
}
