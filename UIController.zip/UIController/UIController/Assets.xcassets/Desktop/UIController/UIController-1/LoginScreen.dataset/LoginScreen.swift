//
//  LoginScreen.swift
//  UIController
//
//  Created by DCS on 09/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class LoginScreen: UIViewController {
    private var myPagecontrol: UIPageControl = {
        let pc = UIPageControl ()
        pc.numberOfPages = 3
        pc.currentPage = 0
        pc.tintColor = .black
        
        pc.addTarget(self, action: #selector(NextPage), for: .valueChanged)
        return pc
    }()
    
    private var nameTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Username.."
        textField.textAlignment = .center
        textField.borderStyle = .roundedRect
        textField.backgroundColor = .lightGray
        
        return textField
    }()
    private var passTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Password.."
        textField.textAlignment = .center
        textField.borderStyle = .roundedRect
        textField.backgroundColor = .lightGray
        return textField
    }()
    private let loginButton: UIButton = {
        let button = UIButton();
        button.setTitle("Login", for: .normal)
        button.addTarget(self, action: #selector(login), for: .touchUpInside)
        button.tintColor = .white
        button.backgroundColor = .blue
        button.layer.cornerRadius = 6
        return button
    }()
    private let myLabel: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "Don't have an Account?"
        label.textColor = .black
        label.textAlignment = .center
        return label
    }()
    private let mySwitch: UISwitch = {
        let s = UISwitch()
        s.isOn = false
        s.onTintColor = .red
        return s
    }()
    private let myremember: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "Remember me"
        label.textColor = .black
        label.textAlignment = .center
        return label
    }()
    private let RegButton: UIButton = {
        let button = UIButton();
        button.setTitle("Click here", for: .normal)
        button.addTarget(self, action: #selector(reg), for: .touchUpInside)
        button.tintColor = .black
        button.backgroundColor = .lightGray
        button.layer.cornerRadius = 6
        return button
    }()
    @objc func login(){
        print("Button Click")
        if(nameTextField.text == "Admin" && passTextField.text == "Admin"){
            /*let s1 = TableView()
            self.dismiss(animated: true)
            navigationController?.pushViewController(s1, animated: true)
            present(s1,animated: true, completion: nil)*/
        }
    }
    @objc func NextPage(){
        login()
    }
    @objc func reg(){
        let s1 = Registration()
        self.dismiss(animated: true)
        navigationController?.pushViewController(s1, animated: true)
        present(s1,animated: true, completion: nil)    }
        
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
        view.addSubview(nameTextField)
        view.addSubview(passTextField)
        view.addSubview(loginButton)
        view.addSubview(myLabel)
        view.addSubview(RegButton)
        view.addSubview(myPagecontrol)
        view.addSubview(mySwitch)
        view.addSubview(myremember)
        //self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Backgroung.png") ?
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super .viewDidLayoutSubviews()
        
        nameTextField.frame = CGRect(x: 40, y: 225, width: view.width - 80, height: 40)
        passTextField.frame = CGRect(x: 40 ,y: 275, width: view.width - 80, height: 40)
        mySwitch.frame = CGRect(x: 60, y: passTextField.bottom + 10, width: 50, height: 40)
        myremember.frame = CGRect(x: mySwitch.right + 10, y: passTextField.bottom + 10, width: view.width - 250, height: 40)
        loginButton.frame = CGRect(x: 60, y: mySwitch.bottom + 10, width: view.width - 120, height: 40)
        myLabel.frame = CGRect(x: 60, y: loginButton.bottom + 10, width: view.width - 120, height: 40)
        RegButton.frame = CGRect(x: 80, y: myLabel.bottom + 10, width: view.width - 130, height: 40)
        myPagecontrol.frame = CGRect(x: 100, y: RegButton.bottom, width: view.width - 200, height: 40)
    }
    

}
