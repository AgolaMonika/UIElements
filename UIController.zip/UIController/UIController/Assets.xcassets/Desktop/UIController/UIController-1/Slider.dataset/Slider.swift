//
//  Slider.swift
//  UIController
//
//  Created by DCS on 09/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class Slider: UIViewController {
    
    private let myProgress: UIProgressView = {
        let progress = UIProgressView()
        progress.setProgress(0.0, animated: true)
        return progress
    }()
    private let mySlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 0
        slider.maximumValue = 10
        slider.addTarget(self, action: #selector(sliderChange), for: .valueChanged)
        return slider
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(mySlider)

      
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 10.0){
            print("progress")
            self.myProgress.setProgress(0.5, animated: true)
        }
    }
    @objc func sliderChange(){
        print(mySlider.value)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewDidLayoutSubviews()
        mySlider.frame = CGRect(x: 50, y: 20, width: 200, height: 40)
    }
    

    

}
