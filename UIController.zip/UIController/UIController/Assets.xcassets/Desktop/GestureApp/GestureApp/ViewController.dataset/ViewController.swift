//
//  ViewController.swift
//  GestureApp
//
//  Created by DCS on 03/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private var myView: UIView {
        let view = UIView()
        view.backgroundColor = .gray
        view.frame = CGRect(x: 100, y: 100, width: 200, height: 200)
        return view
    }
        

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(myView)
        let pan = UIPanGestureRecognizer(target: self, action: #selector(didPanView))
        view.addGestureRecognizer(pan)
        
        
        
        /*let leftswip = UISwipeGestureRecognizer(target: self, action: #selector(didleftSwip))
        leftswip.direction = .left
        view.addGestureRecognizer(leftswip)
        let rightswip = UISwipeGestureRecognizer(target: self, action: #selector(didleftSwip))
        leftswip.direction = .right
        view.addGestureRecognizer(rightswip)
        let upswip = UISwipeGestureRecognizer(target: self, action: #selector(didleftSwip))
        leftswip.direction = .up
        view.addGestureRecognizer(upswip)
        let downswip = UISwipeGestureRecognizer(target: self, action: #selector(didleftSwip))
        leftswip.direction = .down
        view.addGestureRecognizer(downswip)*/
        
        
        
        
        //let rotation = UIRotationGestureRecognizer(target: self, action: #selector(didRotationView))
        //view.addGestureRecognizer(rotation)
       // let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(didPinchView))
        //view.addGestureRecognizer(pinchGesture)
        //let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapView))
        
        // Do any additional setup after loading the view.
    }


}
extension ViewController{
    
    @objc private func didPanView(gesture : UIPanGestureRecognizer){
        let x = gesture.location(in: view).x
        let y = gesture.location(in: view).y
        
        myView.center = CGPoint(x: x, y: y)
    }
    /*
    @objc func didleftSwip(gesture: UISwipeGestureRecognizer){
        if(gesture.direction == .left){
            UIView.animate(withDuration: 0.5){
                self.myView.frame = CGRect(x: self.myView.frame.origin.x-40, y: self.myView.frame.origin.y, width: 200, height: 200)
                
            }
            
        }
        else if(gesture.direction == .right){
            myView.frame = CGRect(x: myView.frame.origin.x+40, y: myView.frame.origin.y, width: 200, height: 200)
        }
        else if(gesture.direction == .up){
            myView.frame = CGRect(x: myView.frame.origin.x, y: myView.frame.origin.y-40, width: 200, height: 200)
        }
        else if(gesture.direction == .down){
            myView.frame = CGRect(x: myView.frame.origin.x, y: myView.frame.origin.y+40, width: 200, height: 200)
        }
        
    }*/
        
    
    //Rotation
    //@objc private func didRotationView(gesture: UIRotationGestureRecognizer){
      //  myView.transform=CGAffineTransform(rotationAngle: gesture.rotation)
    //}
    //PinchGesture
    
}

