//
//  Registration.swift
//  UIController
//
//  Created by DCS on 09/12/21.
//  Copyright © 2021 DCS. All rights reserved.
//

import UIKit

class Registration: UIViewController {
    private var emailTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter Email.."
        textField.textAlignment = .center
        textField.borderStyle = .roundedRect
        textField.backgroundColor = .lightGray
        
        return textField
    }()
    private let activity: UIActivityIndicatorView = {
        let activity = UIActivityIndicatorView()
        activity.color = .blue
        //activity.backgroundColor = .red
        //activity.startAnimating()
        return activity
    }()
    private let myLabel: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "Registration"
        label.textColor = .black
        label.textAlignment = .center
       
        return label
    }()
    private let myHeight: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "Height"
        label.textColor = .black
        label.textAlignment = .left
        
        return label
    }()
    private let mySlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 3.1
        slider.maximumValue = 8.0
        slider.addTarget(self, action: #selector(sliderChange), for: .valueChanged)
        return slider
    }()
    private let mydob: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "Date of Birth"
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    private let myDatePicker: UIDatePicker = {
        let date = UIDatePicker()
        date.timeZone = NSTimeZone.local
        date.datePickerMode = UIDatePicker.Mode.date
        return date
    }()
    private let DayText: UILabel = {
        let day = UILabel()
        day.text = "Number of Day "
        day.textColor = .black
        return day
    }()
    
    private let steplabel: UILabel = {
        var label = UILabel()
        //label.backgroundColor = .gray
        label.text = "1"
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    private let upButton: UIButton = {
        let btn = UIButton()
        btn.setTitle("Image", for: .normal)
        btn.backgroundColor = .lightGray
        
        btn.addTarget(self, action: #selector(Upload), for: .touchUpInside)
        btn.layer.cornerRadius = 5
        return btn
    }()
    /*private let uploadBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("Image", for: .normal)
        btn.backgroundColor = .lightGray
        
        btn.addTarget(self, action: #selector(Upload), for: .touchUpInside)
        btn.layer.cornerRadius = 5
        return btn
    }()*/
    
    private let myStepper: UIStepper = {
        let step = UIStepper()
        step.minimumValue = 1
        step.maximumValue = 7
        step.value = 1
        step.tintColor = .black
        step.addTarget(self, action: #selector(changestep), for: .touchUpInside)
        return step
    }()
    
    private let mySegment: UISegmentedControl = {
        let segment = UISegmentedControl()
        segment.insertSegment(withTitle: "Mon", at: 0, animated: true)
        segment.insertSegment(withTitle: "Tue", at: 1, animated: true)
        segment.insertSegment(withTitle: "Wed", at: 2, animated: true)
        segment.insertSegment(withTitle: "Thu", at: 3, animated: true)
        segment.insertSegment(withTitle: "Fri", at: 4, animated: true)
        segment.insertSegment(withTitle: "Sat", at: 5, animated: true)
        segment.insertSegment(withTitle: "Sun", at: 6, animated: true)
        segment.selectedSegmentIndex = 0
        segment.tintColor = .black
        
        return segment
    }()
    private let toolbar:UIToolbar = {
        let toolbar = UIToolbar()
        let cancel = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(handelCancel))
        let camera = UIBarButtonItem(barButtonSystemItem: .organize, target: self, action: #selector(handelCancel))
        let gallery = UIBarButtonItem(barButtonSystemItem: .camera, target: self, action: #selector(handelCancel))
        toolbar.items = [cancel,camera,gallery]
        return toolbar
    }()
    @objc func handelCancel(){
        print("click ToolBar")
        self.dismiss(animated: true)
    }
   
    private let imagepicker : UIImagePickerController = {
        let img = UIImagePickerController()
        img.allowsEditing = true
        return img
        }()
    private let imageview : UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "Cross")
        img.clipsToBounds = true
        return img
    }()
    
    private let tabbar: UITabBar = {
        let tab = UITabBar()
        let history = UITabBarItem(tabBarSystemItem: .history, tag: 1)
        let downloads = UITabBarItem(tabBarSystemItem: .downloads, tag: 2)
        tab.items = [history,downloads]
        return tab
    }()
    private let upload: UIButton = {
        let btn = UIButton()
        btn.setTitle("Upload", for: .normal)
        btn.backgroundColor = .lightGray
        
        btn.addTarget(self, action: #selector(Uploadbtn), for: .touchUpInside)
        btn.layer.cornerRadius = 5
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
        view.addSubview(emailTextField)
        view.addSubview(myLabel)
        view.addSubview(activity)
        view.addSubview(myHeight)
        view.addSubview(mySlider)
        view.addSubview(mydob)
        view.addSubview(myDatePicker)
        view.addSubview(myStepper)
        view.addSubview(steplabel)
        view.addSubview(DayText)
        view.addSubview(mySegment)
        view.addSubview(upButton)
        view.addSubview(imageview)
        view.addSubview(toolbar)
        view.addSubview(tabbar)
        view.addSubview(upload)
        imagepicker.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        toolbar.frame = CGRect(x: 0, y: 10, width: view.width, height: 30)
        myLabel.frame = CGRect(x: 40, y: 40, width: view.width - 120, height: 60)
        emailTextField.frame = CGRect(x: 40, y: myLabel.bottom + 10, width: view.width-80, height: 40)
        myHeight.frame = CGRect(x: 40, y: emailTextField.bottom + 30, width: 100, height: 40)
        mySlider.frame = CGRect(x: 40, y: myHeight.bottom + 5, width: view.width - 80, height: 20)
        mydob.frame = CGRect(x: 40, y: mySlider.bottom + 10, width: 100, height: 40)
        myDatePicker.frame = CGRect(x: mydob.right + 10, y: mySlider.bottom + 10, width: 200, height: 40)
        DayText.frame = CGRect(x: 40, y: myDatePicker.bottom + 10, width: 120, height: 40)
        steplabel.frame = CGRect(x: DayText.right + 5, y: myDatePicker.bottom + 10, width: 20, height: 40)
        myStepper.frame = CGRect(x: steplabel.right + 5, y: myDatePicker.bottom + 10, width: 50, height: 40)
        mySegment.frame = CGRect(x: 40, y: myStepper.bottom + 10, width: view.width - 40, height: 40)
        upButton.frame = CGRect(x: 40, y: mySegment.bottom + 10, width: 80, height: 40)
        imageview.frame = CGRect(x: upButton.right + 10, y: mySegment.bottom + 10, width: 150, height: 150)
        upload.frame = CGRect(x: imageview.right + 5, y: mySegment.bottom + 10, width: 80, height: 40)
        activity.frame = CGRect(x: 120, y: imageview.bottom + 30, width: view.width - 200, height: 40)
        tabbar.frame = CGRect(x: 0, y:activity.bottom + 20 , width: view.width, height: 40)
        
    }
    @objc func sliderChange(){
        print(mySlider.value)
    }
    @objc func changestep(){
        steplabel.text = "\(Int(myStepper.value))"
       
    }
    
    @objc func Upload(){
        imagepicker.sourceType = .photoLibrary
        DispatchQueue.main.async {
            self.present(self.imagepicker,animated: true)
        }
    }
    
    
}
extension Registration : UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let getImage = info[.originalImage] as? UIImage{
            imageview.image = getImage
        }
        imagepicker.dismiss(animated: true)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            imagepicker.dismiss(animated: true)
    }
    
    @objc func Uploadbtn(){
        activity.startAnimating()
    }
}
